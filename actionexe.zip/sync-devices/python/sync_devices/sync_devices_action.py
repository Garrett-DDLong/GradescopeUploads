import ncs
from ncs.dp import Action

class SyncDevicesAction(Action):
    @Action.action
    def cb_action(self, uinfo, name, kp, input, output, trans):
        with ncs.maapi.single_read_trans('admin','python') as trans:
            root = ncs.maagic.get_root(trans)
            out = root.devices.check_sync()
            devsForSync = []
            allSynced = True
            for result in out.sync_result:
                dev = result.device
                r = result.result
                self.log.info(dev, ' ' ,r)
                if r == 'out-of-sync':
                    devsForSync.append(dev)
                    allSynced = False
                    self.log.info(r)
            output.devices = devsForSync
            output.result = allSynced
            for dev in devsForSync:
                root.devices.device[dev].sync_from()

