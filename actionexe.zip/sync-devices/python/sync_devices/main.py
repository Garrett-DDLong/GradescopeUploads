import ncs
from .sync_devices_action import SyncDevicesAction

class Main(ncs.application.Application):
    def setup(self):
        self.register_action('sync-devices-action', SyncDevicesAction)


